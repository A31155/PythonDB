import pymysql

try:
    mon=input('modelname: ')
    cm=input('company name : ')
    ram=input('ram: ')
    rom=input('rom: ')
    col=input('color: ')
    scr=input('screen: ')
    batt=input('battery: ')
    pro=input('processor: ')
    pri=int(input('price: '))
    rat=float(input('rating: ')) 


    con=pymysql.connect(host='beb3i9nns90uwaukxhns-mysql.services.clever-cloud.com',user='utybmbk7dttjirwx',password='zkmhWsDwaXIfTFueVu1B',database='beb3i9nns90uwaukxhns')
    curs=con.cursor()

    try:
        curs.execute("insert into mobiles values('%s','%s','%s','%s','%s','%s','%s','%s','%d',%.2f)" %(mon,cm,ram,rom,col,scr,batt,pro,pri,rat))
        con.commit()
        print('mobiles data stored in the cloud')
    except Exception as e:
        print('this data cant be inserted - ',e)

    con.close()
except:
    print('invalid input')
