import pymysql

con=pymysql.connect(host='beb3i9nns90uwaukxhns-mysql.services.clever-cloud.com',user='utybmbk7dttjirwx',password='zkmhWsDwaXIfTFueVu1B',database='beb3i9nns90uwaukxhns')
curs=con.cursor()

mn=input('Enter MODEL_NAME : ')

curs.execute("select * from mobiles where  MODEL_NAME='%s'" %mn)
data=curs.fetchone()

if data:
    pr=input('Enter purpose : ')
    curs.execute("update mobiles set purpose= '%s' where MODEL_NAME ='%s'" %(pr,mn))
    con.commit()
    print('purpose data updated')
else:
    print('company name not found')
con.close()
