import pymysql

con=pymysql.connect(host='beb3i9nns90uwaukxhns-mysql.services.clever-cloud.com',user='utybmbk7dttjirwx',password='zkmhWsDwaXIfTFueVu1B',database='beb3i9nns90uwaukxhns')
curs=con.cursor()

cm=input('Enter COMPANY_NAME : ')

curs.execute("select * from mobiles where COMPANY_NAME='%s'" %cm)
data=curs.fetchone()

if data:
    pr=int(input('Enter Price : '))
    curs.execute("update mobiles set price= %d where COMPANY_NAME ='%s'" %(pr,cm))
    con.commit()
    print('price data updated')
else:
    print('company name not found')
con.close()
