import pymysql

con=pymysql.connect(host='beb3i9nns90uwaukxhns-mysql.services.clever-cloud.com',user='utybmbk7dttjirwx',password='zkmhWsDwaXIfTFueVu1B',database='beb3i9nns90uwaukxhns')
curs=con.cursor()

cn=input('COMPANY_NAME: ')
curs.execute("select * from mobiles where COMPANY_NAME='%s'" %cn)
data=curs.fetchone()

if data:
    curs.execute("delete from mobiles where COMPANY_NAME='%s'" %cn)
    con.commit()
    print('company name deleted successfully')
else:
    print('company name does not exist')

con.close()
