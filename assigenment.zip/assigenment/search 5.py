import pymysql

con=pymysql.connect(host='beb3i9nns90uwaukxhns-mysql.services.clever-cloud.com',user='utybmbk7dttjirwx',password='zkmhWsDwaXIfTFueVu1B',database='beb3i9nns90uwaukxhns')
curs=con.cursor()

mn=input('Enter MODEL_NAME : ')
curs.execute("select * from mobiles where MODEL_NAME='%s'" %mn)
data=curs.fetchone()

print(data)
try:
    print(data[1])
    print(data[3])
except:
    print('model name does not exist')

con.close()
