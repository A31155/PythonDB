import pymysql

con=pymysql.connect(host='beb3i9nns90uwaukxhns-mysql.services.clever-cloud.com',user='utybmbk7dttjirwx',password='zkmhWsDwaXIfTFueVu1B',database='beb3i9nns90uwaukxhns')
curs=con.cursor()

cm=input('Enter COMPANY_NAME : ')
curs.execute("select * from mobiles where ORDER BY price ASC =%d " %cm)
data=curs.fetchall()

#print(data)
try:
    print(data[0])
    print(data[1])
    print(data[2])
    print(data[3])
    print(data[4])
    
except:
    print('company does not exist')

con.close()
